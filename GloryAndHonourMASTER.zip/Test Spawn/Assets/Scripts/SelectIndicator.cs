﻿using UnityEngine;

public class SelectIndicator : MonoBehaviour
{
    private SelectManager selectManager;
    private Vector3 objectPosition;
    private Vector3 objectScale;
    private Vector3 boxColliderTransform;
    private Vector3 boxCollider;

    private void Start()
    {
        selectManager = FindObjectOfType<SelectManager>();
    }

    private void Update()
    {
        if (selectManager.selectedObject != null)
        {
            //TARGET OBJECT POSITION
            objectPosition = selectManager.selectedObject.GetComponent<Transform>().position;
            this.transform.position = new Vector3(objectPosition.x, 0.001f, objectPosition.z);

            //TARGET OBJECT SCALE
            if (selectManager.selectedObject.GetComponent<BoxCollider>() != null)
            {
                boxColliderTransform = selectManager.selectedObject.GetComponent<Transform>().transform.localScale;
                objectScale = selectManager.selectedObject.GetComponent<BoxCollider>().size;
                objectScale.x *= boxColliderTransform.x;
                objectScale.z *= boxColliderTransform.z;
                this.transform.localScale = new Vector3(objectScale.x *= 1.4f, 0.002f, objectScale.z *= 1.4f);
            }
            else if (selectManager.selectedObject.GetComponent<SphereCollider>() != null)
            {
                objectScale = selectManager.selectedObject.GetComponent<SphereCollider>().bounds.size;
                this.transform.localScale = new Vector3(objectScale.x *= 1.4f, 0.002f, objectScale.z *= 1.4f);
            }
            else if (selectManager.selectedObject.GetComponent<CapsuleCollider>() != null)
            {
                objectScale = selectManager.selectedObject.GetComponent<CapsuleCollider>().bounds.size;
                this.transform.localScale = new Vector3(objectScale.x *= 1.4f, 0.002f, objectScale.z *= 1.4f);
            }
            else if (selectManager.selectedObject.GetComponent<TerrainCollider>() != null)
            {
                this.transform.position = new Vector3(0f, 0f, 0f);
                this.transform.localScale = new Vector3(0f, 0f, 0f);
            }
        }
        else if (selectManager.selectedObject == null)
        {
            this.transform.position = new Vector3(0f, 0f, 0f);
            this.transform.localScale = new Vector3(0f, 0f, 0f);
        }
    }
}
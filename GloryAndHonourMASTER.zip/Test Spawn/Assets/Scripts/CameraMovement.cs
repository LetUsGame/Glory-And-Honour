﻿using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    public Vector2 cameraBounds;

    private float panSpeed;
    private float panBorderThickness;
    private Vector3 cameraPosition;

    private void Start()
    {
        panSpeed = 20.00f;
        panBorderThickness = 10.00f;
    }

    private void Update()
    {
        cameraPosition = transform.position;
        float mPosX = Input.mousePosition.x;
        float mPosY = Input.mousePosition.y;

        if (Input.GetKey("up") || mPosY >= Screen.height - panBorderThickness)
        {
            cameraPosition.z -= panSpeed * Time.deltaTime;
            cameraPosition.x += panSpeed * Time.deltaTime;
        }
        if (Input.GetKey("down") || mPosY <= panBorderThickness)
        {
            cameraPosition.z += panSpeed * Time.deltaTime;
            cameraPosition.x -= panSpeed * Time.deltaTime;
        }
        if (Input.GetKey("right") || mPosX >= Screen.width - panBorderThickness)
        {
            cameraPosition.z -= panSpeed * Time.deltaTime;
            cameraPosition.x -= panSpeed * Time.deltaTime;
        }
        if (Input.GetKey("left") || mPosX <= panBorderThickness)
        {
            cameraPosition.z += panSpeed * Time.deltaTime;
            cameraPosition.x += panSpeed * Time.deltaTime;
        }
        cameraPosition.x = Mathf.Clamp(cameraPosition.x, -cameraBounds.x, cameraBounds.x);
        cameraPosition.z = Mathf.Clamp(cameraPosition.z, -cameraBounds.y, cameraBounds.y);
        transform.position = cameraPosition;
    }
}
﻿using System.Collections.Generic;
using UnityEngine;

public class PlaceableBuilding : MonoBehaviour
{
    public List<Collider> colliders = new List<Collider>();

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Building")
            colliders.Add(other);
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Building")
            colliders.Remove(other);
    }
}
﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class GUIButtonUnitSpawn : MonoBehaviour
{
    public Rect buttonPosition;
    public Texture btnTexture;
    public GameObject spawnUnit;
    public GameObject gameController;
    public float spawnTime = 3f;
    public int woodCost, stoneCost, oreCost;

    [SerializeField]
    private Text errorText;

    [SerializeField]
    private GameObject spawnObjPos;

    private Vector3 spawnPoint;
    private Queue unitQueue;

    private void Awake()
    {
        gameController = GameObject.FindGameObjectWithTag("GameController");
        errorText = GameObject.FindGameObjectWithTag("ErrorText").GetComponentInChildren<Text>();
    }

    private void OnGUI()
    {
        if (GUI.Button(buttonPosition, btnTexture))
        {
            gameController.GetComponent<SelectManager>().enabled = true;
            int wood = ResourceManager.wood;
            int stone = ResourceManager.stone;
            int ore = ResourceManager.ore;

            if (wood < woodCost || stone < stoneCost || ore < oreCost)
            {
                if (wood < woodCost && stone < stoneCost && ore < oreCost)
                {
                    errorText.text = "Not Enough Wood! " + (woodCost - wood) + " Required!";
                    errorText.text += "\nNot Enough Stone! " + (stoneCost - stone) + " Required!";
                    errorText.text += "\nNot Enough Ore! " + (oreCost - ore) + " Required!";
                }
                else if (wood < woodCost && stone < stoneCost)
                {
                    errorText.text = "Not Enough Wood! " + (woodCost - wood) + " Required!";
                    errorText.text += "\nNot Enough Stone! " + (stoneCost - stone) + " Required!";
                }
                else if (wood < woodCost && ore < oreCost)
                {
                    errorText.text = "Not Enough Wood! " + (woodCost - wood) + " Required!";
                    errorText.text += "\nNot Enough Ore! " + (oreCost - ore) + " Required!";
                }
                else if (stone < stoneCost && ore < oreCost)
                {
                    errorText.text = "Not Enough Stone! " + (stoneCost - stone) + " Required!";
                    errorText.text += "\nNot Enough Ore! " + (oreCost - ore) + " Required!";
                }
                else if (wood < woodCost)
                {
                    errorText.text = "Not Enough Wood! " + (woodCost - wood) + " Required!";
                }
                else if (stone < stoneCost)
                {
                    errorText.text = "Not Enough Stone! " + (stoneCost - stone) + " Required!";
                }
                else if (ore < oreCost)
                {
                    errorText.text = "Not Enough Ore! " + (oreCost - ore) + " Required!";
                }
                else
                    errorText.text = "Not Enough Resources!";
            }
            else
            {
                spawnPoint = spawnObjPos.transform.position;
                Invoke("Spawn", spawnTime);
                ResourceManager.wood -= woodCost;
                ResourceManager.stone -= stoneCost;
                ResourceManager.ore -= oreCost;
            }
        }
    }

    private void Spawn()
    {
        Instantiate(spawnUnit, spawnPoint, spawnObjPos.transform.rotation);
    }
}
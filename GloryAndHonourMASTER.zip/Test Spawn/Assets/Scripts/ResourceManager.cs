﻿using UnityEngine;
using UnityEngine.UI;

public class ResourceManager : MonoBehaviour
{
    public static int wood, stone, ore;
    public Text woodText, stoneText, oreText;
    public Text errorText;

    private void Awake()
    {
        wood = 200;
        stone = 200;
        ore = 200;
    }

    private void Update()
    {
        woodText.text = "Wood: " + wood;
        stoneText.text = "Stone: " + stone;
        oreText.text = "Ore: " + ore;
    }
}
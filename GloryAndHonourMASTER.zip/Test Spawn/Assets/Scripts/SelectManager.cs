﻿using UnityEngine;

public class SelectManager : MonoBehaviour
{
    public GameObject selectedObject;

    private GameObject hitObject;
    private Ray ray;
    private RaycastHit hitInfo;

    public Texture2D selectionHighlight;
    public static Rect selection = new Rect(0, 0, 0, 0);
    private Vector3 startClick = -Vector3.one;

    private void Update()
    {
        #region Individual Selection
        if (Input.GetMouseButtonDown(0))
        {
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hitInfo))
            {
                hitObject = hitInfo.transform.root.gameObject;
                SelectedObject(hitObject);
            }
            else
                ClearSelection();
        }
        #endregion Individual selection

        #region Drag Multiple Selection
        if (Input.GetMouseButtonDown(0))
            startClick = Input.mousePosition;
        else if (Input.GetMouseButtonUp(0))
            startClick = -Vector3.one;

        if (Input.GetMouseButton(0))
        {
            selection = new Rect(startClick.x, InvertMouseY(startClick.y), Input.mousePosition.x - startClick.x, InvertMouseY(Input.mousePosition.y) - InvertMouseY(startClick.y));

            if (selection.width < 0)
            {
                selection.x += selection.width;
                selection.width = -selection.width;
            }
            if (selection.height < 0)
            {
                selection.y += selection.height;
                selection.height = -selection.height;
            }
        }
        #endregion Drag Multiple Selection
    }

    #region Drag Multiple Selection Methods
    private void OnGUI()
    {
        if (startClick != -Vector3.one)
        {
            GUI.color = new Color(1, 1, 1, 0.5f);
            GUI.DrawTexture(selection, selectionHighlight);
        }
    }

    public static float InvertMouseY(float y)
    {
        return Screen.height - y;
    }
    #endregion 

    #region Individual Selection Methods
    private void SelectedObject(GameObject obj)
    {
        if (selectedObject != null)
        {
            if (obj == selectedObject)
                return;
            ClearSelection();
        }
        selectedObject = obj;
    }

    private void ClearSelection()
    {
        if (selectedObject == null)
            return;
        selectedObject = null;
    }
    #endregion Individual Selection
}
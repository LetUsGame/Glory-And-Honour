﻿using UnityEngine;
using UnityEngine.UI;

public class BuildingPlacement : MonoBehaviour
{
    public Text errorText;

    private PlaceableBuilding placeableBuilding;
    private Transform currentBuilding;
    private ConstructionCost constructionCost;
    private Camera camera;
    private Vector3 mouse;
    private bool hasPlaced;

    private void Start()
    {
        camera = GameObject.FindGameObjectWithTag("CameraRig").GetComponentInChildren<Camera>();
    }

    private void Update()
    {
        if (currentBuilding != null && !hasPlaced)
        {
            mouse = Input.mousePosition;
            //mouse = new Vector3(mouse.x, mouse.y, transform.position.z); /*ENABLE THIS IF CAMERA IS PERSPECTIVE*/
            Vector3 cameraPosition = camera.ScreenToWorldPoint(mouse);
            currentBuilding.position = new Vector3(cameraPosition.x, 0.001f, cameraPosition.z);
            if (Input.GetMouseButton(0))
                if (IsColliderClear())
                {
                    hasPlaced = true;
                }
        }
    }

    private bool IsColliderClear()
    {
        if (placeableBuilding.colliders.Count > 0)
            return false;
        return true;
    }

    public void SetItem(GameObject building)
    {
        hasPlaced = false;
        int woodCost = building.GetComponent<ConstructionCost>().woodCost;
        int stoneCost = building.GetComponent<ConstructionCost>().stoneCost;
        int oreCost = building.GetComponent<ConstructionCost>().oreCost;
        int wood = ResourceManager.wood;
        int stone = ResourceManager.stone;
        int ore = ResourceManager.ore;

        if (wood < woodCost || stone < stoneCost || ore < oreCost)
        {
            if (wood < woodCost && stone < stoneCost && ore < oreCost)
            {
                errorText.text = "Not Enough Wood! " + (woodCost - wood) + " Required!";
                errorText.text += "\nNot Enough Stone! " + (stoneCost - stone) + " Required!";
                errorText.text += "\nNot Enough Ore! " + (oreCost - ore) + " Required!";
            }
            else if (wood < woodCost && stone < stoneCost)
            {
                errorText.text = "Not Enough Wood! " + (woodCost - wood) + " Required!";
                errorText.text += "\nNot Enough Stone! " + (stoneCost - stone) + " Required!";
            }
            else if (wood < woodCost && ore < oreCost)
            {
                errorText.text = "Not Enough Wood! " + (woodCost - wood) + " Required!";
                errorText.text += "\nNot Enough Ore! " + (oreCost - ore) + " Required!";
            }
            else if (stone < stoneCost && ore < oreCost)
            {
                errorText.text = "Not Enough Stone! " + (stoneCost - stone) + " Required!";
                errorText.text += "\nNot Enough Ore! " + (oreCost - ore) + " Required!";
            }
            else if (wood < woodCost)
            {
                errorText.text = "Not Enough Wood! " + (woodCost - wood) + " Required!";
            }
            else if (stone < stoneCost)
            {
                errorText.text = "Not Enough Stone! " + (stoneCost - stone) + " Required!";
            }
            else if (ore < oreCost)
            {
                errorText.text = "Not Enough Ore! " + (oreCost - ore) + " Required!";
            }
            else
                errorText.text = "Not Enough Resources!";
            currentBuilding = null;
        }
        else
        {
            ResourceManager.wood -= woodCost;
            ResourceManager.stone -= stoneCost;
            ResourceManager.ore -= oreCost;
            currentBuilding = ((GameObject)Instantiate(building)).transform;
            placeableBuilding = currentBuilding.GetComponent<PlaceableBuilding>();
        }
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BuildingHitPoints : MonoBehaviour
{

    public Image healthBar;
    public float hitPointMax;
    private float hitPointsCurrent;

    void Start ()
    {
        hitPointsCurrent = hitPointMax;
	}
	
	void Update ()
    {
		
	}

    public void TakeDamage(float damageAmount)
    {
        hitPointsCurrent -= damageAmount;
        healthBar.fillAmount = hitPointsCurrent - hitPointMax;
    }
}

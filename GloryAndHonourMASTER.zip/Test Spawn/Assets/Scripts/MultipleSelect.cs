﻿using UnityEngine;

public class MultipleSelect : MonoBehaviour
{
    public bool selected = false;
    private Renderer renderer;
    private Camera camera;
    private GameObject selectedIndicator;

    void Start()
    {
        renderer = GetComponent<Renderer>();
        camera = GameObject.FindGameObjectWithTag("CameraRig").GetComponentInChildren<Camera>();
    }

    void Update()
    {
        if (renderer.isVisible && Input.GetMouseButton(0))
        {
            Vector3 cameraPosition = Camera.main.WorldToScreenPoint(transform.position);
            cameraPosition.y = SelectManager.InvertMouseY(cameraPosition.y);
            selected = SelectManager.selection.Contains(cameraPosition);
        }

        if (selected)
            renderer.material.color = Color.red;
        else
            renderer.material.color = Color.white;
    }
}

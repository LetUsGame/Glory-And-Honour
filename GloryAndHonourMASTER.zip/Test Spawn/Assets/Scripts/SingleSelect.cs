﻿using UnityEngine;
using UnityEngine.UI;

public class SingleSelect : MonoBehaviour
{
    public GameObject selectManager;
    public SelectManager selectManagerScript;
    private GameObject thisObject;

    private void Awake()
    {
        thisObject = this.gameObject;
        selectManager = GameObject.FindGameObjectWithTag("GameController");
        selectManagerScript = selectManager.GetComponent<SelectManager>();
    }

    private void Update()
    {
        if (selectManagerScript.selectedObject != null)
        {
            if (selectManagerScript.selectedObject == thisObject)
            {
                GetComponent<GUIButtonUnitSpawn>().enabled = true;
            }
            else
            {
                GetComponent<GUIButtonUnitSpawn>().enabled = false;
            }
        }
    }
}
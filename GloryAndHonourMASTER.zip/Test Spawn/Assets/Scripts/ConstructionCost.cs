﻿using UnityEngine;

public class ConstructionCost : MonoBehaviour
{
    public int woodCost;
    public int stoneCost;
    public int oreCost;
}

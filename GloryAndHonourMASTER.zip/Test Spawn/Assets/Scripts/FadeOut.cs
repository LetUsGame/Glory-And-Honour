﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class FadeOut : MonoBehaviour
{
    private Text errorText;

    private void Awake()
    {
        errorText = GameObject.FindGameObjectWithTag("ErrorText").GetComponentInChildren<Text>();
    }

    private void Update()
    {
        if (errorText.text != "")
        {
            Invoke("ClearText", 3);
        }
        else if(errorText.text == "")
        {
            CancelInvoke();
        }
    }

    void ClearText()
    {
        errorText.text = "";
    }
}
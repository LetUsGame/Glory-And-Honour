﻿using UnityEngine;

public class CameraZoom : MonoBehaviour
{
    public Camera camera;

    private void Update()
    {
        //Camera zoom
        if (camera.orthographicSize == 10) { } //Zoom in STOP
        else
        if (Input.GetAxis("Mouse ScrollWheel") > 0 || Input.GetKey("q")) //Zoom in
            camera.orthographicSize -= 4;

        if (camera.orthographicSize == 70) { } //Zoom out STOP
        else
        if (Input.GetAxis("Mouse ScrollWheel") < 0 || Input.GetKey("w")) //Zoom out
            camera.orthographicSize += 4;
    }
}